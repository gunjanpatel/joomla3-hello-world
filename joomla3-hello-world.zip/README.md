Hello World Component for Joomla 3 beginners
===================

# Travis Status
Master: [![Build Status](https://travis-ci.org/gunjanpatel/joomla3-hello-world.png?branch=master)](https://travis-ci.org/gunjanpatel/joomla3-hello-world)

NSERT IGNORE INTO `#__helloworld_category`
(`id`, `parent_id`, `lft`, `rgt`, `level`, `title`,
`image`, `alias`, `access`, `path`, `published`,
`checked_out`, `checked_out_time`, `created_user_id`)
VALUES
(1, 0, 0, 489, 0, 'root', '', 'root', 0, '', 1, 0, '0000-00-00 00:00:00', 50);